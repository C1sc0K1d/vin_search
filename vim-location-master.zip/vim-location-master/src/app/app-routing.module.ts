import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService, UrlConsumerService } from '@sade/ng-adfs';
import { VimMapPageComponent } from './vim-location/pages/vim-map-page/vim-map-page.component';

const routes: Routes = [
  {
    path: "access_token",
    component: VimMapPageComponent,
    canActivate: [UrlConsumerService]
  },
  {
    path: 'find',
    component: VimMapPageComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: '',
    redirectTo: '/find',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})

export class AppRoutingModule {}
