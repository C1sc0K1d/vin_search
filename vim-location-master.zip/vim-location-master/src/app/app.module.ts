import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AuthGuardService, Env, NgADFSModule, UrlConsumerService, UserIdService } from '@sade/ng-adfs';
import { BlockUIModule } from 'ng-block-ui';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { VimMapModule } from './vim-location/vim-location.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    VimMapModule,
    NgADFSModule.forRoot({
      clientId: 'urn:locationbyvim:clientid:web_vimlocation:qa',
      environment: Env.QA,
      resourceUri: 'urn:locationbyvim:resource:web_vimlocation:qa'
  }),
  BlockUIModule.forRoot()
  ],
  providers: [
    UrlConsumerService,
    AuthGuardService,
    UserIdService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
