export class BaseBodyError {
    errorCode!: string;
    messages!: string[];
    dataErrors!: DataError[];
    attributes!: Map<string, object>;
}

export class DataError {
    code!: string;
    name!: string;
    value!: string;
    message!: string;
  }