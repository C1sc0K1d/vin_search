import { Odometer } from "./odometer.model"
import { Location } from "./location.model"

export class Historic {
    odometer!: Odometer;
    location!: Location;
    apiTimestamp!: Date;
    createdAt!: Date;
}