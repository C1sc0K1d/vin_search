export class Location {
    lat!: number;
    lon!: number;
    alt!: number
}