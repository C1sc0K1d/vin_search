export class Odometer {
    metricKind!: string;
    value!: number;
    units!: string;
}