import { BaseBodyError } from "../base-body-error.model";

export class BaseBodyResponse<R> {
    result: R | undefined;
    error!: BaseBodyError;
}