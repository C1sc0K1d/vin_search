import { Vin } from "../vin.model";

export class VinResponse {
    vin!: Vin;
}