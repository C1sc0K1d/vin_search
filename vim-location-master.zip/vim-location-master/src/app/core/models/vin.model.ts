import { Historic } from "./historic.model";

export class Vin {
    vin!: string;
    historic!: Historic[];
}