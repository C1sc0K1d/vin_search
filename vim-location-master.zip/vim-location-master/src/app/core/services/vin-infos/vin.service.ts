import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { environment } from "src/environments/environment";
import { Vin } from "../../models/vin.model";

@Injectable({
    providedIn: 'root'
})
export class VinService {

    private url: string = environment.apiUrl + '/api/v1/vehicles';

    constructor(private client: HttpClient){}

    public getInfosByVin(vin: string): Observable<Vin> {
        return this.client.get<Vin>(`${this.url}/${vin}`);
    }
}