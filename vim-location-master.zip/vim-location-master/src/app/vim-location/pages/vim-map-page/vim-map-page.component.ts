import { Component, OnInit, ViewChild, ElementRef, NgZone} from '@angular/core';
import { MapsAPILoader } from '@agm/core';
import { VinService } from 'src/app/core/services/vin-infos/vin.service';
import { BlockUI, NgBlockUI } from 'ng-block-ui';

@Component({
  selector: 'app-vim-map-page',
  templateUrl: './vim-map-page.component.html',
  styleUrls: ['./vim-map-page.component.scss']
})
export class VimMapPageComponent implements OnInit {

  //lat = 51.678418;
  //lng = 7.809007;

  vin!: string;
  
  lat!: number;
  lng!: number;
  zoom!: number;
  address!: string;

  private geoCoder!: google.maps.Geocoder;

  @ViewChild('search')
  public searchElementRef!: ElementRef;

  @BlockUI() blockUI!: NgBlockUI;

  constructor(
    private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone,
    private vinService: VinService
  ) { }

  private setCurrentLocation() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.lat = position.coords.latitude;
        this.lng = position.coords.longitude;
        this.zoom = 8;
        this.getAddress(this.lat, this.lng);
      });
    }
  }

  private getAddress(latitude: number, longitude: number) {
    this.geoCoder.geocode({ 'location': { lat: latitude, lng: longitude } }, (results, status) => {
      if (status === 'OK') {
        if (results[0]) {
          this.zoom = 12;
          this.address = results[0].formatted_address;
        } else {
          window.alert('No results found');
        }
      } //else {
        //window.alert('Geocoder failed due to: ' + status);
      //}
    
    });
  }

  searchByVin(): void {
    if(this.vin){
      this.blockUI.start('Searching...');
      this.vinService.getInfosByVin(this.vin).subscribe(infos => {
        if (infos.historic[0].location && (infos.historic[0].location.lat !== 0 && infos.historic[0].location.lon !== 0)) {
          console.log(infos.historic[0].location);
          
          this.lat = infos.historic[0].location.lat;
          this.lng = infos.historic[0].location.lon;
          this.blockUI.stop();
        }else{
          alert('Vin não possui endereço.')
          this.blockUI.stop();
        }
      }, error => {
        console.log(error);
        this.blockUI.stop();
      });
    }
  }

  ngOnInit() {
    this.mapsAPILoader.load().then(() => {
      this.setCurrentLocation();
      this.geoCoder = new google.maps.Geocoder;
    });
  }

}
