import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { AgmCoreModule } from '@agm/core';

import { VimMapPageComponent } from "./pages/vim-map-page/vim-map-page.component";

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        BrowserModule,
        AgmCoreModule.forRoot({
            apiKey: '',
            libraries: ['places']
          })
    ],
    exports: [],
    declarations: [
        VimMapPageComponent
    ]
})
export class VimMapModule {}