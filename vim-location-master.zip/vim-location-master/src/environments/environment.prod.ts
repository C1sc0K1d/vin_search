export const environment = {
  production: true,
  apiUrl: 'https://sade-ubi-dev.apps.pp01i.edc1.cf.ford.com'
};
